// src/App.jsx
import React, { useState } from "react";
import AddBookForm from "./components/AddBookForm";
import BookList from "./components/BookList";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

export default function App() {
  // refreshSignal toggles when a new book is added so BookList re-fetches
  const [refreshSignal, setRefreshSignal] = useState(0);
  const handleAdded = () => setRefreshSignal((s) => s + 1);

  return (
    <div>
      <h1 style={{ textAlign: "center", marginTop: 16 }}>📚 Book Inventory</h1>
      <AddBookForm onAdded={handleAdded} />
      <BookList refreshSignal={refreshSignal} />
      <ToastContainer position="top-right" autoClose={2000} />
    </div>
  );
}
