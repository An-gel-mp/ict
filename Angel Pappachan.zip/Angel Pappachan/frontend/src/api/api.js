import axios from "axios";

// 👇 Set your backend URL here
const api = axios.create({
  baseURL: "http://localhost:5000/api", // <-- Change port if your backend runs on another port
});

export default api;
