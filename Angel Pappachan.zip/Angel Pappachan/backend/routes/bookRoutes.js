import express from "express";
import Book from "../models/Book.js";

const router = express.Router();

//
// ✅ POST /api/books → Add a new book with validation
//
router.post("/", async (req, res) => {
  try {
    const { title, author, genre, price, stock, publishedYear } = req.body;

    // 🧠 Validation: Check required fields
    if (!title || !author || !genre || !price) {
      return res.status(400).json({
        message: "❌ Missing required fields: title, author, genre, and price are required.",
      });
    }

    // 🆕 Create and save new book
    const newBook = new Book({
      title,
      author,
      genre,
      price,
      stock: stock || 0,
      publishedYear,
    });

    await newBook.save();

    res.status(201).json({
      message: "✅ Book added successfully!",
      book: newBook,
    });
  } catch (error) {
    console.error("Error adding book:", error);
    res.status(500).json({ message: "❌ Server Error", error: error.message });
  }
});

export default router;
